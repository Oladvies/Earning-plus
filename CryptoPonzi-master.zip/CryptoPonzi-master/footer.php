	<div id="footer">
		<p>&copy; 2014 Crypton | Powered by <a href="https://github.com/Crypton33/CryptoPonzi">CryptoPonzi</a> script</p>
	</div>
	</div>
</body>
</html>